package com.kechuang.kechuang;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KechuangApplicationTests {

	@Test
	void contextLoads() {
	}

}
