package com.kechuang.kechuang.service;

import com.kechuang.kechuang.pojo.Mqs;

public interface QuestionService {
    void questioninsert(Mqs mqs);
}
