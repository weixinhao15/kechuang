package com.kechuang.kechuang.service;

import com.kechuang.kechuang.pojo.Mqs;

public interface QuestionService {
    void questioninsert(Mqs mqs);

    Mqs selectbyid(Mqs mqs);

   void updatequestion(Mqs mqs);
}
