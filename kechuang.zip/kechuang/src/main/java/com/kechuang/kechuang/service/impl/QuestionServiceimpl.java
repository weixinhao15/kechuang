package com.kechuang.kechuang.service.impl;

import com.kechuang.kechuang.mapper.QuestionMapper;
import com.kechuang.kechuang.pojo.Mqs;
import com.kechuang.kechuang.service.QuestionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Service
public class QuestionServiceimpl implements QuestionService {
    @Autowired
    private QuestionMapper questionMapper;
     public void questioninsert(Mqs mqs){

         mqs.setCreatetime(LocalDateTime.now());
         questionMapper.questioninsert(mqs);

    }

    public Mqs selectbyid(Mqs mqs){
        return questionMapper.selectbyid(mqs);
    }

    public void updatequestion(Mqs mqs){
         mqs.setCreatetime(LocalDateTime.now());
         questionMapper.updatequestion(mqs);

    };
}
