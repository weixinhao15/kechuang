package com.kechuang.kechuang.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Mqs {
    private int id;
    private String username;
    private String question;
    private String description;
    private int subject;
    private LocalDateTime createtime;
}
