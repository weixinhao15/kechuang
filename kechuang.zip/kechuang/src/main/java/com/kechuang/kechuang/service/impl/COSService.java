package com.kechuang.kechuang.service.impl;

import com.qcloud.cos.COSClient;
import com.qcloud.cos.model.ObjectMetadata;
import com.qcloud.cos.model.PutObjectRequest;
import com.qcloud.cos.model.PutObjectResult;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.util.UUID;

@Service
public class COSService {
    @Autowired
    private COSClient cosClient;

    @Value("${cos.bucketName}")
    private String bucketName;

    public String uploadFile(MultipartFile file) throws IOException {
        // 1. 创建临时文件
        File localFile = File.createTempFile("temp", null);
        file.transferTo(localFile);

        // 2. 设置上传文件的名称，可以使用 UUID 来避免重复
        String key = UUID.randomUUID().toString() + "_" + file.getOriginalFilename();

        // 3. 设置文件的元数据，尤其是 Content-Type
        ObjectMetadata metadata = new ObjectMetadata();
        metadata.setContentLength(file.getSize());
        metadata.setContentType(file.getContentType());  // 设置 Content-Type

        // 4. 创建上传请求，并绑定元数据
        PutObjectRequest putObjectRequest = new PutObjectRequest(bucketName, key, localFile);
        putObjectRequest.setMetadata(metadata);

        // 5. 上传文件
        PutObjectResult putObjectResult = cosClient.putObject(putObjectRequest);

        // 6. 返回文件的 URL
        String fileUrl = "https://" + bucketName + ".cos." + cosClient.getClientConfig().getRegion().getRegionName() + ".myqcloud.com/" + key;

        // 删除临时文件
        localFile.delete();

        return fileUrl;
    }
}