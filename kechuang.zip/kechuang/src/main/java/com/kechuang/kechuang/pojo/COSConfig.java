package com.kechuang.kechuang.pojo;

import com.qcloud.cos.COSClient;
import com.qcloud.cos.ClientConfig;
import com.qcloud.cos.auth.BasicCOSCredentials;
import com.qcloud.cos.auth.COSCredentials;
import com.qcloud.cos.region.Region;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class COSConfig {

    @Value("${cos.secretId}")
    private String secretId;

    @Value("${cos.secretKey}")
    private String secretKey;

    @Value("${cos.region}")
    private String region;

    @Bean
    public COSClient cosClient() {
        // 1. 初始化用户身份信息（secretId, secretKey）。
        COSCredentials cred = new BasicCOSCredentials(secretId, secretKey);

        // 2. 设置 bucket 的区域，例如 ap-guangzhou
        ClientConfig clientConfig = new ClientConfig(new Region(region));

        // 3. 生成 COS 客户端。
        return new COSClient(cred, clientConfig);
    }
}