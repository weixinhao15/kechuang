package com.kechuang.kechuang.service;

import com.kechuang.kechuang.pojo.Loginer;

public interface LoginService {
    public Loginer login(Loginer loginer);
}
