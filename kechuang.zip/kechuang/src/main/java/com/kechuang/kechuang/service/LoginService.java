package com.kechuang.kechuang.service;

import com.kechuang.kechuang.pojo.Loginer;
import com.kechuang.kechuang.pojo.Result;

public interface LoginService {
    public Loginer login(Loginer loginer);

    Result register(Loginer loginer);

    Loginer selectbyname(Loginer loginer);
}
