package com.kechuang.kechuang.controller;

import com.kechuang.kechuang.pojo.Mqs;
import com.kechuang.kechuang.pojo.Result;
import com.kechuang.kechuang.service.impl.QuestionServiceimpl;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@Slf4j
public class QuestionController {

    @Autowired
    private QuestionServiceimpl questionService;
    @PostMapping("/mqs")
    public Result questioninsert(@RequestBody Mqs mqs){
       log.info("提问");
       questionService.questioninsert(mqs);
       return Result.success();


    }
}
