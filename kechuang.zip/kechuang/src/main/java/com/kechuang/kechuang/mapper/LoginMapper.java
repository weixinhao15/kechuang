package com.kechuang.kechuang.mapper;

import com.kechuang.kechuang.pojo.Loginer;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

@Mapper
public interface LoginMapper {

    @Select("select * from user where username=#{username} and password=#{password}")
    Loginer getby(Loginer loginer);

    @Insert("insert into user(username,password,createtime,updatetime) values(#{username},#{password},#{createtime},#{updatetime})")
    void insert(Loginer loginer);

    @Select("select * from user where username=#{username}")
    Loginer selectbynema(Loginer loginer);
}
