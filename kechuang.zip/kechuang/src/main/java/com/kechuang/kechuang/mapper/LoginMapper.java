package com.kechuang.kechuang.mapper;

import com.kechuang.kechuang.pojo.Loginer;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

@Mapper
public interface LoginMapper {

    @Select("select * from user where username=#{username} and password=#{password}")
    Loginer getby(Loginer loginer);
}
