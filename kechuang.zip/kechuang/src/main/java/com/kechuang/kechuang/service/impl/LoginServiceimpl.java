package com.kechuang.kechuang.service.impl;

import com.kechuang.kechuang.mapper.LoginMapper;
import com.kechuang.kechuang.pojo.Loginer;
import com.kechuang.kechuang.service.LoginService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class LoginServiceimpl implements LoginService {
    @Autowired
    private LoginMapper loginMapper;

    public Loginer login(Loginer loginer) {
        return loginMapper.getby(loginer);
    }
}
