package com.kechuang.kechuang.service.impl;

import com.kechuang.kechuang.mapper.LoginMapper;
import com.kechuang.kechuang.pojo.Loginer;
import com.kechuang.kechuang.pojo.Result;
import com.kechuang.kechuang.service.LoginService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Service
public class LoginServiceimpl implements LoginService {
    @Autowired
    private LoginMapper loginMapper;

    public Loginer login(Loginer loginer) {
        return loginMapper.getby(loginer);
    }

    public Result register(Loginer loginer) {
        loginer.setCreatetime(LocalDateTime.now());
        loginer.setUpdatetime(LocalDateTime.now());

       Loginer sn= loginMapper.selectbynema(loginer);
        if(sn==null){
        loginMapper.insert(loginer);
        return Result.success();
        }
        else return Result.error("注册失败");
    }

    public Loginer selectbyname(Loginer loginer) {
        return loginMapper.selectbynema(loginer);
    }
}
