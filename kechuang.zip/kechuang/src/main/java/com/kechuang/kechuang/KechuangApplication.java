package com.kechuang.kechuang;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KechuangApplication {

	public static void main(String[] args) {
		SpringApplication.run(KechuangApplication.class, args);
	}

}
