package com.kechuang.kechuang.mapper;

import com.kechuang.kechuang.pojo.Mqs;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

@Mapper
public interface QuestionMapper {

    @Insert("insert into mathquestions(username,question,description,createtime,subject) values(#{username},#{question},#{description},#{createtime},#{subject})")
     void questioninsert(Mqs mqs);

    @Select("select * from mathquestions where id=#{id}")
    Mqs selectbyid(Mqs mqs);

    void updatequestion(Mqs mqs);
}
