package com.kechuang.kechuang.mapper;

import com.kechuang.kechuang.pojo.Mqs;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface QuestionMapper {

    @Insert("insert into mathquestions(username,question,description,createtime) values(#{username},#{question},#{description},#{createtime})")
     void questioninsert(Mqs mqs);
}
