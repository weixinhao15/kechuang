package com.kechuang.kechuang.controller;

import com.kechuang.kechuang.pojo.JwtUtils;
import com.kechuang.kechuang.pojo.Loginer;
import com.kechuang.kechuang.pojo.Result;
import com.kechuang.kechuang.service.impl.LoginServiceimpl;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@Slf4j
@RestController
public class LoginControllor {
        @Autowired
        private LoginServiceimpl loginService;

        @PostMapping("/login")
        public Result login(@RequestBody Loginer loginer) {

            Loginer l = loginService.login(loginer);
            log.info("用户{}登录", l);
            if (l != null) {
                Map<String, Object> claims = new HashMap<>();
                claims.put("id", l.getId());
                claims.put("username", l.getUsername());
                claims.put("password", l.getPassword());
                String jwt = JwtUtils.generateJwt(claims);
                return Result.success(jwt);
            }
            log.info("用户{}登录", l);
            return Result.error("密码或用户名错误");
        }

        @PostMapping("/register")
        public Result register(@RequestBody Loginer loginer) {
            log.info("注册用户{}", loginer);
            return loginService.register(loginer);
        }

        @PostMapping("/sbn")
        public Result selectbyname(@RequestBody Loginer loginer) {
            Loginer sn=loginService.selectbyname(loginer);
            return Result.success();
        }
    }
